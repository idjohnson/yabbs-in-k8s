# Blank Paths.pm file

1;